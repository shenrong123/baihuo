//1.引入router
var express = require('express');
var router = express.Router();
 
//2.引入mongoose的数据模块
var mongoose = require('mongoose'); 
var Goods = require('./goods');
 
//3.连接数据库
mongoose.connect('mongodb://localhost:27017/shenrong');
 
mongoose.connection.on( 'connected', () => {
	console.log('数据库连接成功！');
});
 
mongoose.connection.on( 'error', () => {
	console.log('数据库连接失败！');
});
 
mongoose.connection.on( 'disconnected', () => {
	console.log('数据库连接断开！');
});
/* GET users listing. */
//4.路由获取
router.get('/', function(req, res, next) {
	//5.查询mongoDB的goods数据  基于mongoose实现商品列表的查询
	Goods.find({},function(err,doc){
		if(err){
			res.json({
				status:'1',
				msg:err.message
			})
		}else{
			res.json({
				status:'0',
				msg:'',
				result:{
					count:doc.length,
					list:doc
				}
			})
		}
 
	})
  	// res.send('hello,goods');
});
 
//6.暴露路由
module.exports = router;