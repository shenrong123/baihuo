//加载mongoose模块
var mongoose = require("mongoose");
//Schema表模型   获取mongoose的Schema
var Schema = mongoose.Schema;
//定义商品模型
var produtSchema = new Schema({
  customerId: String,
  truename: String,
  totalMoney: Number,
  orders: [
    {
      status: Boolean, // 商品状态
      shopId: String, // 商品编号
      name: String, // 商品名称
      code: String, // 商品code
      category: String, // 商品类别
      exportPrice: Number, // 商品批发价
      dealPrice: String, // 商品成交价
      number: Number // 商品成数量
    }
  ],
  finishTime: String // 订单完成时间
});
//把mongoose的 model中 goods模块暴露出来
module.exports = mongoose.model("OrderList", produtSchema);
