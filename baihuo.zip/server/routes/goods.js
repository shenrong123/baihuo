//1.引入router
var express = require("express");
var router = express.Router();

//2.引入mongoose的数据模块
var mongoose = require("mongoose");
var Goods = require("../models/goods");
var Login = require("../models/login");
var OrderList = require("../models/orderList");

//3.连接数据库
mongoose.connect("mongodb://localhost:27017/dumall");

mongoose.connection.on("connected", () => {
  console.log("数据库连接成功！");
});

mongoose.connection.on("error", () => {
  console.log("数据库连接失败！");
});

mongoose.connection.on("disconnected", () => {
  console.log("数据库连接断开！");
});

// router.all('*', function(req, res, next) {
//     res.header("Access-Control-Allow-Origin", "*");
//     res.header("Access-Control-Allow-Headers", "X-Requested-With");
//     res.header("Access-Control-Allow-Methods","PUT,POST,GET,DELETE,OPTIONS");
//     res.header("X-Powered-By",' 3.2.1')
//     res.header("Content-Type", "application/json;charset=utf-8");
//     next();
// });

// 用户登陆
router.post("/login", function(req, res, next) {
  console.log(req.body, "-- user info--");
  Login.find(req.body, function(err, doc) {
    if (doc.length > 0) {
      //   res.redirect("/goods/list");
      res.json({
        success: true,
        message: "",
        result: {
          count: doc.length,
          list: doc
        }
      });
    } else {
      res.json({
        success: false,
        message: "用户名或密码错误！",
        result: {
          count: doc.length,
          list: doc
        }
      });
    }
  });
});

// 判断用户名
router.post("/judgeUsername", function(req, res, next) {
  console.log(req.body, "-- edit goods -- ");
  Login.find(req.body, function(err, doc) {
    if (doc.length > 0) {
      // console.log(err, "--err--");
      res.json({
        status: "0",
        success: false,
        message: "该姓名重复！",
        result: {
          count: doc.length,
          list: doc
        }
      });
    } else {
      res.json({
        status: "1",
        success: true,
        message: "",
        result: {
          count: doc.length,
          list: doc
        }
      });
    }
    // console.log(doc, "--judge--");
  });
});

// 用户列表
router.post("/accountList", function(req, res, next) {
  //5.查询mongoDB的goods数据  基于mongoose实现商品列表的查询
  //   console.log(req, 5555);
  // Goods.find({age : {$gt : 10}},function(err,doc){
  var length = null;
  var pagesize = req.body.size || 10;
  var currentindex = req.body.page || 1;
  var params = req.body;
  if (params._id) {
    Login.findById(params._id, function(err, todo) {
      res.json({
        status: "0",
        message: "",
        success: true,
        result: {
          list: todo
        }
      });
    });
  } else {
    delete params.page;
    delete params.size;
    // console.log(params, "--params--");
    if (Object.keys(params).length > 0) {
      for (var i in params) {
        params[i] = new RegExp(params[i]);
      }
    }
    Login.find(params, (err, result) => {
      // console.log(res.length, "--res length--");
      // console.log(result, "--result--");
      length = result.length;

      Login.find(params)
        .skip(pagesize * (currentindex - 1))
        .limit(pagesize)
        .sort({ _id: -1 })
        .exec(function(err, doc) {
          // console.log(length, "--length--");
          //   console.log(doc, 111111);
          if (err) {
            res.json({
              status: "1",
              success: false,
              message: err.message
            });
          } else {
            res.json({
              status: "0",
              message: "",
              success: true,
              result: {
                count: length,
                list: doc
              }
            });
          }
        });
    });
  }
  // res.send('hello,goods');
});

// 添加用户
router.post("/addAccount", function(req, res, next) {
  // console.log(req.body, "add goods");
  new Login(req.body).save(function(err, todo, count) {
    //保存数据
    // console.log('内容', todo, '数量', count); //打印保存的数据
    // res.send(todo);
    res.json({
      success: true
    });
    // res.redirect('/'); //返回首页
  });
});

// 修改列表
router.post("/editAccount", function(req, res, next) {
  // console.log(req.body, "-- edit goods -- ");
  var oldPassword = req.body.oldPassword;
  Login.findById(req.body._id, function(err, todo) {
    var flag = true;
    for (const i in req.body) {
      if (req.body.isAdmin) {
        todo.password = req.body.password;
        flag = false;
      } else {
        if (Number(todo.password) === Number(oldPassword)) {
          todo.password = req.body.password;
          flag = false;
        }
      }
    }
    if (!flag) {
      todo.save();
      res.json({
        success: true
      });
    } else {
      res.json({
        success: false,
        message: "旧密码不对"
      });
    }
  });
});

/* GET users listing. */
//4.路由获取
router.post("/list", function(req, res, next) {
  //5.查询mongoDB的goods数据  基于mongoose实现商品列表的查询
  //   console.log(req, 5555);
  // Goods.find({age : {$gt : 10}},function(err,doc){
  var length = null;
  var pagesize = req.body.size || 10;
  var currentindex = req.body.page || 1;
  var params = req.body;
  if (params._id) {
    Goods.findById(params._id, function(err, todo) {
      res.json({
        status: "0",
        message: "",
        success: true,
        result: {
          list: todo
        }
      });
    });
  } else {
    delete params.page;
    delete params.size;
    // console.log(params, "--params--");
    if (Object.keys(params).length > 0) {
      for (var i in params) {
        params[i] = new RegExp(params[i]);
      }
    }
    Goods.find(params, (err, result) => {
      // console.log(res.length, "--res length--");
      // console.log(result, "--result--");
      length = result.length;

      Goods.find(params)
        .skip(pagesize * (currentindex - 1))
        .limit(pagesize)
        .sort({ _id: -1 })
        .exec(function(err, doc) {
          // console.log(length, "--length--");
          //   console.log(doc, 111111);
          if (err) {
            res.json({
              status: "1",
              success: false,
              message: err.message
            });
          } else {
            res.json({
              status: "0",
              message: "",
              success: true,
              result: {
                count: length,
                list: doc
              }
            });
          }
        });
    });
  }
  // res.send('hello,goods');
});

router.post("/addGoods", function(req, res, next) {
  // console.log(req.body, "add goods");
  new Goods(req.body).save(function(err, todo, count) {
    //保存数据
    // console.log('内容', todo, '数量', count); //打印保存的数据
    // res.send(todo);
    res.json({
      success: true
    });
    // res.redirect('/'); //返回首页
  });
});

// 获取订单列表
router.post("/getOrderList", function(req, res, next) {
  var params = {};
  if (req.body.customerId) {
    params.customerId = req.body.customerId;
  }
  if (req.body.orderId) {
    params._id = req.body.orderId;
  }
  var length = null;
  var pagesize = req.body.size || 10;
  var currentindex = req.body.page || 1;
  OrderList.find(params, (err, result) => {
    length = result.length;
    OrderList.find(params)
      .skip(pagesize * (currentindex - 1))
      .limit(pagesize)
      .sort({ _id: -1 })
      .exec(function(err, doc) {
        if (err) {
          res.json({
            status: "1",
            success: false,
            message: err.message
          });
        } else {
          res.json({
            status: "0",
            message: "",
            success: true,
            result: {
              count: length,
              list: doc
            }
          });
        }
      });
  });
});

// 查询订单列表条数
router.post("/shopmallLists", function(req, res, next) {
  var params = {
    customerId: req.body.customerId
  };
  OrderList.find(params)
    .sort({ _id: -1 })
    .exec(function(err, doc) {
      if (doc.length && !doc[0].finishTime) {
        res.json({
          success: true,
          result: {
            shopCount: doc[0].orders.length,
            list: doc[0].orders
          }
        });
      } else {
        res.json({
          success: true,
          result: {
            shopCount: 0,
            list: []
          }
        });
      }
    });
});

// 编辑订单中的商品
router.post("/editOrderList", function(req, res, next) {
  var params = {
    customerId: req.body.customerId
  };
  OrderList.find(params)
    .sort({ _id: -1 })
    .exec(function(err, doc) {
      OrderList.findById(doc[0]._id, function(err, todo) {
        if (req.body.shopIds) {
          var shopIds = req.body.shopIds;
          todo.orders = todo.orders.filter(item => {
            return shopIds.indexOf(item.shopId) === -1;
          });
        } else if (req.body.finishTime) {
          var selectedIds = req.body.selectedIds;
          todo.orders = todo.orders.filter(item => {
            return selectedIds.indexOf(item.shopId) !== -1;
          });
          todo.finishTime = req.body.finishTime;
          todo.totalMoney = req.body.totalMoney;
        } else {
          todo.orders.map(function(item, index) {
            if (item.shopId === req.body.shopId) {
              todo.orders[index].number = req.body.number;
            }
          });
        }
        todo.save();
        res.json({
          success: true
        });
      });
    });
});

// 添加订单列表
router.post("/addOrderList", function(req, res, next) {
  // console.log(req.body, "add goods");
  var params = {
    customerId: req.body.customerId
  };
  OrderList.find(params)
    .sort({ _id: -1 })
    .exec(function(err, doc) {
      if (doc.length && !doc[0].finishTime) {
        OrderList.findById(doc[0]._id, function(err, todo) {
          var flag = false;
          todo.orders.map(function(item, index) {
            delete item._id;
            if (item.shopId === req.body.orders.shopId) {
              flag = true;
              const number =
                Number(todo.orders[index].number) +
                Number(req.body.orders.number);
              todo.orders[index] = req.body.orders;
              todo.orders[index].number = number;
            }
          });
          if (!flag) {
            todo.orders.push(req.body.orders);
          }
          todo.save();
          res.json({
            success: true
          });
          // console.log(todo, "--todo--");
        });
      } else {
        const params = {
          truename: req.body.truename,
          customerId: req.body.customerId,
          orders: [req.body.orders]
        };
        // console.log(req.body.truename,'--true name--')
        // console.log(params, "--params--");
        if (req.body.finishTime) {
          params.finishTime = req.body.finishTime;
        }
        new OrderList(params).save(function(err, todo, count) {
          res.json({
            success: true
          });
        });
      }
    });
  // new OrderList(req.body).save(function(err, todo, count) {
  //   //保存数据
  //   // console.log('内容', todo, '数量', count); //打印保存的数据
  //   // res.send(todo);
  //   res.json({
  //     success: true
  //   });
  //   // res.redirect('/'); //返回首页
  // });
});

// 修改列表
router.post("/editGoods", function(req, res, next) {
  // console.log(req.body, "-- edit goods -- ");
  Goods.findById(req.body._id, function(err, todo) {
    OrderList.find({}, function(err, orderTodo) {
      for (const i in req.body) {
        if (i !== "_id") {
          todo[i] = req.body[i];
        }
      }
      if (orderTodo.length) {
        for (var i of orderTodo) {
          if (i.orders.length) {
            OrderList.findById(i._id, function(err, orderListTodo) {
              console.log(orderListTodo, "--order list --");
              for (var j of orderListTodo.orders) {
                if (j.shopId === req.body._id) {
                  j.status = req.body.status;
                }
              }
              orderListTodo.save();
            });
          }
        }
      }
      console.log(todo, "--change shop status--");

      // todo.name = req.body.name;
      // todo.age = req.body.age;
      todo.save();
      res.json({
        success: true
      });
    });
  });
});

// 判断姓名唯一性
router.post("/judgeOne", function(req, res, next) {
  console.log(req.body, "-- edit goods -- ");
  Goods.find(req.body, function(err, doc) {
    if (doc.length > 0) {
      // console.log(err, "--err--");
      res.json({
        status: "0",
        success: false,
        message: "该姓名重复！",
        result: {
          count: doc.length,
          list: doc
        }
      });
    } else {
      res.json({
        status: "1",
        success: true,
        message: "",
        result: {
          count: doc.length,
          list: doc
        }
      });
    }
    // console.log(doc, "--judge--");
  });
});

// 删除
router.post("/deleteGoods", function(req, res, next) {
  // console.log(req.body, "-- delete goods -- ");
  Goods.findById(req.body._id, function(err, todo) {
    todo.remove(function(err, todo) {
      //   res.send(todo);
      res.json({
        success: true
      });
    });
  });

  // Goods.remove(req.body._id, function(err, todo) {
  // 		console.log(err,'--delete')
  // 		res.send(todo)
  // });
});
//6.暴露路由
module.exports = router;
