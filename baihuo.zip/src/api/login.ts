import { axiosAjax } from "./common";

export default {
  // 用户登录 密码登录
  login(params: object) {
    return axiosAjax("/goods/login", "post", {
      data: params
    });
  },

  // 用户列表
  accountList(params: object) {
    return axiosAjax("/goods/accountList", "post", {
      data: params
    });
  },

  // 判断用户名是否唯一
  judgeUsername(params: object) {
    return axiosAjax("/goods/judgeUsername", "post", {
      data: params
    });
  },

  // 添加用户
  addAccount(params: object) {
    return axiosAjax("/goods/addAccount", "post", {
      data: params
    });
  },

  // 修改用户
  editAccount(params: object) {
    return axiosAjax("/goods/editAccount", "post", {
      data: params
    });
  },
};
