<template>
  <div class="create-commodity-container">
    <h1>{{accountId?'编辑用户':'新增用户'}}</h1>
    <Divider></Divider>
    <Row :style="{ 'padding-top': '20px' }">
      <Col :xs="{ span: 16, offset: 4 }" :lg="{ span: 12, offset: 6 }">
        <Form ref="formItem" :model="formItem" :rules="formValidate" :label-width="100">
          <FormItem label="用户名" prop="username">
            <Input v-model="formItem.username" :maxlength="80" placeholder="请输入用户命"></Input>
          </FormItem>
          <FormItem label="真实姓名" prop="truename">
            <Input v-model="formItem.truename" :maxlength="80" placeholder="请输入真实姓名"></Input>
          </FormItem>
          <FormItem label="密码：" prop="password">
            <Input v-model="formItem.password" :maxlength="10" placeholder="请输入密码"></Input>
          </FormItem>
          <!-- <FormItem label="商品图片：" prop="code">
            <Input v-model="formItem.code" :maxlength="10" placeholder="请输入商品Code"></Input>
          </FormItem>-->
          <FormItem label="角色类别：" prop="category">
            <Select v-model="formItem.category" placeholder="请选择角色类别" :disabled="userInfo.username === formItem.username">
              <Option
                v-for="item in roleType"
                :value="item.value"
                :key="item.value"
              >{{ item.label }}</Option>
            </Select>
          </FormItem>
          <FormItem label="手机号码：" prop="mobile">
            <Input v-model="formItem.mobile" :maxlength="11" placeholder="请输入11位手机号码"></Input>
          </FormItem>
          <FormItem>
            <Button
              :to="{ name: 'accountList', params: { type: 'all'} }"
              style="margin-right: 8px"
            >取消</Button>
            <Button type="primary" :loading="sending" @click="handleSubmit()">
              <span v-if="!sending">提交</span>
              <span v-else>提交中...</span>
            </Button>
          </FormItem>
        </Form>
      </Col>
    </Row>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from "vue-property-decorator";

@Component({
  components: {}
})
export default class CreateAccount extends Vue {
  // 获取用户信息
  get userInfo() {
    var items: any = sessionStorage.getItem("userInfo");
    return JSON.parse(items);
  }

  // 提交按钮状态
  private sending = false;

  private accountId: string = ""; // 商品id

  // 表单数据
  private formItem: any = {
    username: "",
    password: "",
    truename:"",
    category: "",
    mobile: ""
  };

  // 初始化用户名
  private accountName = "";

  // 商品分类
  private roleType: any = [
    {
      value: "admin",
      label: "管理员"
    },
    {
      value: "user",
      label: "普通用户"
    }
  ];

  // 表单校验规则
  private formValidate = {
    username: [{ required: true, message: "用户名不能为空", trigger: "blur" }],
    truename: [{ required: true, message: "真实姓名不能为空", trigger: "blur" }],
    mobile: [
      { required: true, message: "电话号码不能为空", trigger: "blur" },
      {
        type: "string",
        pattern: /^1[0-9]{10}$/,
        message: "手机号格式输入错误！"
      }
    ],
    category: [
      { required: true, message: "角色分类不能为空", trigger: "blur" }
    ],
    password: [{ required: true, message: "密码不能为空", trigger: "blur" }]
  };

  // 获取某商品的信息
  private getAccountDetail() {
    const params = {
      _id: this.accountId
    };
    this.$store.dispatch("accountList", params).then((res: any) => {
      this.formItem.username = res.list.username;
      this.formItem.truename = res.list.truename;
      this.formItem.password = res.list.password+'';
      this.accountName = res.list.username;
      this.formItem.category = res.list.category;
      this.formItem.mobile = res.list.mobile;
    });
  }

  private created() {
    console.log(this.$route.params.accountId, "6666666");
    this.accountId = this.$route.params.accountId;
    if (this.accountId) {
      this.getAccountDetail();
    }
  }

  // 表单提交
  private handleSubmit() {
    const form: any = this.$refs.formItem;
    form
      .validate()
      .then((res: boolean) => {
        // 校验成功否
        return new Promise((resolve, reject) => {
          res ? resolve() : reject();
        });
      })
      .then(() => {
        if (this.accountName === this.formItem.username) {
          return true;
        }
        const params = {
          username: this.formItem.username
        };
        return this.$store.dispatch("judgeUsername", params);
      })
      .then(() => {
        // 按钮显示 loading 状态
        this.sending = true;

        // 调接口
        const params: any = {
          ...this.formItem
        };
        if (this.accountId) {
          params._id = this.accountId;
          params.isAdmin = true;
          return this.$store.dispatch("editAccount", params);
        } else {
          return this.$store.dispatch("addAccount", params);
        }
      })
      .then(() => {
        if (this.accountId) {
          this.$Message.success("用户修改成功");
        } else {
          this.$Message.success("用户创建成功");
        }
        // 成功则跳转到列表页面
        this.$router.push({ name: "accountList" });
      })
      .catch(() => {
        // 失败弹错
        console.log("fail");
      })
      .finally(() => {
        // loading 状态还原
        this.sending = false;
      });
  }
}
</script>