module.exports = {
    baseUrl: '/',
    outputDir: 'dist',
    assetsDir: '',
    pages: {
      index: {
        entry: 'src/main',
        template: 'public/index.html',
      },
    },
    css: {
      loaderOptions: {
        less: {
          javascriptEnabled: true,
        },
      },
    },
    devServer: {
      open: true, //配置自动启动浏览器
      before(app) {
        app.get('/api/token', (req, res, next) => {
          res.json(loginData);
        });
      },
      // 直联后端时用
      // proxy: {
      //   '^/action|file|export/': {
      //     target: 'http://172.16.0.12:10280/api/resources',
      //   },
      // },
      // 通过 corestone 时用
      proxy: {
        '^/action|file|export/': {
          target: 'http://corestone.cloudcare-basis.svc.cluster.local:8088/api/resources',
          headers: {
            'x-forwarded-host': 'corestone.cloudcare-basis.svc.cluster.local:8088',
          },
          // HOST: 172.16.0.20 testing.shrine-via-core-stone.cloudcare.cn
        },
      },
    },
  };
  