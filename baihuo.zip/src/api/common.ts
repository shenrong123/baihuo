import axios from 'axios';
import { Vue } from 'vue-property-decorator';
import ErrorHandle from '../utils/error-handle';

axios.defaults.withCredentials = true; //跨域保存session有用
axios.defaults.baseURL = "http://localhost:3000";

export function axiosAjax(url: string, method: string, options: object) {
    const defaultOptions = {
      method,
      withCredentials: true,
      timeout: 10000,
    };
    options = Object.assign(
      {
        url: url || '',
        method: method || 'POST',
      },
      defaultOptions,
      options || {}
    );
    return new Promise((resolve, reject) => {
      axios(options)
        .then(res => {
          if (res.data.success) {
            resolve(res.data.result);
          } else {
            // TODO: 如果用户手动删除sessionStorage 之后的报错需特殊处理，并且页面跳转到登陆页(待有时间优化)
            ErrorHandle.showMsg(res.data.code, res.data.message, { type: 'error' });
            reject(res);
          }
        })
        .catch(error => {
          reject(error);
          const errorMessage = error.response;
          ErrorHandle.showMsg(errorMessage.data.code, errorMessage.data.message, { type: 'error' });
        });
    });
  }